package pgos.system;

import java.util.Scanner;

public class LoginManager {

    public String login() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Felhasználónév: ");
        String username = scanner.nextLine();
        System.out.print("Jelszó: ");
        String password = scanner.nextLine(); // Jelszót később lehet titkosítani

        if (username.equals("admin") && password.equals("admin")) {
            System.out.println("Sikeres bejelentkezés. Üdv, " + username + "!");
            return username;
        } else {
            System.out.println("Hibás bejelentkezés.");
            return null;
        }
    }
}