package pgos.system;

import java.io.File;
import java.util.Scanner;

public class ProjectManager {

    public void openProjectManager() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Új projekt neve: ");
        String projectName = scanner.nextLine();

        File projectFolder = new File("projects/" + projectName);
        if (!projectFolder.exists()) {
            if (projectFolder.mkdirs()) {
                System.out.println("Projekt létrehozva: " + projectFolder.getPath());
            } else {
                System.out.println("Nem sikerült létrehozni a projektet.");
            }
        } else {
            System.out.println("Már létezik ilyen projekt.");
        }
    }
}