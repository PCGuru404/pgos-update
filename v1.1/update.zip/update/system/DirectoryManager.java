package pgos.system;

import java.io.File;

public class DirectoryManager {

    public void initializeDirectories() {
        String[] directories = {
                "projects",
                "programs",
                "documents",
                "users",
                "update"
        };

        for (String dir : directories) {
            File folder = new File(dir);
            if (!folder.exists()) {
                if (folder.mkdirs()) {
                    System.out.println("Létrehozva: " + dir);
                } else {
                    System.out.println("Nem sikerült létrehozni: " + dir);
                }
            }
        }
    }
}