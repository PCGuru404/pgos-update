package pgos.system;

import java.io.File;
import java.util.Scanner;

public class FileManager {

    public void openManager() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Mappa útvonala: ");
        String path = scanner.nextLine();

        File folder = new File(path);

        if (folder.exists() && folder.isDirectory()) {
            File[] files = folder.listFiles();
            if (files != null && files.length > 0) {
                for (File f : files) {
                    System.out.println((f.isDirectory() ? "[DIR] " : "[FILE] ") + f.getName());
                }
            } else {
                System.out.println("A mappa üres.");
            }
        } else {
            System.out.println("A mappa nem található.");
        }
    }
}