package pgos.system;

import java.io.File;
import java.io.IOException;
import java.util.Scanner;

public class ProgramRunner {

    public void runProgram() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Program fájl útvonala (.exe, .sh, .jar): ");
        String path = scanner.nextLine();

        File file = new File(path);

        if (!file.exists()) {
            System.out.println("Fájl nem található.");
            return;
        }

        try {
            if (path.endsWith(".jar")) {
                ProcessBuilder pb = new ProcessBuilder("java", "-jar", file.getAbsolutePath());
                pb.inheritIO().start();
            } else if (path.endsWith(".sh")) {
                ProcessBuilder pb = new ProcessBuilder("bash", file.getAbsolutePath());
                pb.inheritIO().start();
            } else if (path.endsWith(".exe")) {
                ProcessBuilder pb = new ProcessBuilder(file.getAbsolutePath());
                pb.inheritIO().start();
            } else {
                System.out.println("Nem támogatott fájltípus.");
            }
        } catch (IOException e) {
            System.out.println("Nem sikerült elindítani: " + e.getMessage());
        }
    }
}