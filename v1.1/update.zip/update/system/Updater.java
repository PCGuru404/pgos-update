package pgos.system;

import java.io.*;
import java.net.URL;
import java.nio.file.*;
import java.util.zip.*;

public class Updater {

    private static final String CURRENT_VERSION = "1.0";
    private static final String UPDATE_BASE_URL = "https://raw.githubusercontent.com/PCGuru404/pgos-update/main/";

    public void checkForUpdates() {
        try {
            System.out.println("Frissítések keresése...");

            // Legújabb verzió lekérése
            String latestVersion = new String(new URL(UPDATE_BASE_URL + "latest.txt").openStream().readAllBytes()).trim();

            if (!latestVersion.equals("v" + CURRENT_VERSION)) {
                System.out.println("Új verzió érhető el: " + latestVersion);
                System.out.println("Letöltés elindítása...");

                // ZIP letöltése
                String zipUrl = "https://github.com/PCGuru404/pgos-updates/raw/main/" + latestVersion + "/update.zip";
                InputStream in = new URL(zipUrl).openStream();
                Files.copy(in, Paths.get("update.zip"), StandardCopyOption.REPLACE_EXISTING);

                // Kicsomagolás
                unzip("update.zip", "update");
                Files.writeString(Path.of("update/update.flag"), "apply");

                System.out.println("Frissítés letöltve. Újraindítás után aktiválódik.");
            } else {
                System.out.println("A rendszer naprakész.");
            }

        } catch (IOException e) {
            System.out.println("Hiba történt a frissítés közben: " + e.getMessage());
        }
    }

    private void unzip(String zipFilePath, String destDir) throws IOException {
        byte[] buffer = new byte[1024];
        ZipInputStream zis = new ZipInputStream(new FileInputStream(zipFilePath));
        ZipEntry zipEntry = zis.getNextEntry();

        while (zipEntry != null) {
            File newFile = new File(destDir, zipEntry.getName());
            if (zipEntry.isDirectory()) {
                newFile.mkdirs();
            } else {
                new File(newFile.getParent()).mkdirs();
                FileOutputStream fos = new FileOutputStream(newFile);
                int len;
                while ((len = zis.read(buffer)) > 0) {
                    fos.write(buffer, 0, len);
                }
                fos.close();
            }
            zipEntry = zis.getNextEntry();
        }

        zis.closeEntry();
        zis.close();
    }
}
