package pgos.system;

import java.io.*;
import java.nio.file.*;

public class UpdateApplier {

    private static final Path UPDATE_DIR = Path.of("update");
    private static final Path FLAG_FILE = UPDATE_DIR.resolve("update.flag");

    public static void applyUpdateIfAvailable() {
        if (Files.exists(FLAG_FILE)) {
            System.out.println("Frissítés alkalmazása folyamatban...");

            try {
                Files.walk(UPDATE_DIR)
                        .filter(path -> !Files.isDirectory(path) && !path.getFileName().toString().equals("update.flag"))
                        .forEach(path -> {
                            try {
                                Path relativePath = UPDATE_DIR.relativize(path);
                                Path targetPath = Path.of("").resolve(relativePath.toString());

                                Files.createDirectories(targetPath.getParent());
                                Files.copy(path, targetPath, StandardCopyOption.REPLACE_EXISTING);
                            } catch (IOException e) {
                                System.out.println("Hiba a fájl másolásakor: " + e.getMessage());
                            }
                        });

                // Flag törlése
                Files.deleteIfExists(FLAG_FILE);
                System.out.println("Frissítés sikeresen alkalmazva!");

            } catch (IOException e) {
                System.out.println("Hiba a frissítés során: " + e.getMessage());
            }

        } else {
            System.out.println("Nincs elérhető frissítés.");
        }
    }
}