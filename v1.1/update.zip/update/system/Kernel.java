package pgos.system;

import java.util.Scanner;

public class Kernel {
    private String username;

    public void start() {
        System.out.println("PGOS kernel elindult!");

        DirectoryManager directoryManager = new DirectoryManager();
        directoryManager.initializeDirectories();

        LoginManager loginManager = new LoginManager();
        username = loginManager.login();

        if (username != null && !username.isEmpty()) {
            showMainMenu();
        } else {
            System.out.println("Sikertelen bejelentkezés. Kilépés...");
            System.exit(0);
        }
    }

    private void showMainMenu() {
        Scanner scanner = new Scanner(System.in);
        boolean running = true;

        while (running) {
            System.out.println("\n--- PGOS Főmenü ---");
            System.out.println("1. Projektkezelő");
            System.out.println("2. Fájlkezelő");
            System.out.println("3. Rendszerinformációk");
            System.out.println("4. Programfuttató");
            System.out.println("5. Frissítés");
            System.out.println("6. Kilépés");
            System.out.print("Válassz egy opciót: ");

            int choice = scanner.nextInt();
            scanner.nextLine();

            switch (choice) {
                case 1 -> new ProjectManager().openProjectManager();
                case 2 -> new FileManager().openManager();
                case 3 -> SystemInfo.showSystemInfo(username);
                case 4 -> runProgram();
                case 5 -> updateSystem();
                case 6 -> {
                    System.out.println("Kilépés...");
                    running = false;
                }
                default -> System.out.println("Érvénytelen választás, próbáld újra!");
            }
        }

        System.exit(0);
    }

    private void runProgram() {
        ProgramRunner runner = new ProgramRunner();
        runner.runProgram();
    }

    private void updateSystem() {
        Updater updater = new Updater();
        updater.checkForUpdates();
    }
}