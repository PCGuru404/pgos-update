package pgos.system;

public class SystemInfo {

    public static void showSystemInfo(String username) {
        System.out.println("Felhasználó: " + username);
        System.out.println("PGOS Verzió: 1.0");
        System.out.println("Operációs rendszer: Java Runtime " + System.getProperty("java.version"));
        System.out.println("Platform: " + System.getProperty("os.name"));
        System.out.println("Architektúra: " + System.getProperty("os.arch"));
    }
}