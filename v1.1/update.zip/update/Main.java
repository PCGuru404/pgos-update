package pgos;

import pgos.system.Kernel;

public class Main {
    public static void main(String[] args) {
        Kernel kernel = new Kernel();
        kernel.start();
    }
}